HOW TO USE:
- Add a script reference to load-progress-bar.js in your HTML, the progress bar will automatically be generated below this reference.
  Ex: <script src="/assets/load-progress-bar.js"></script>
- Ensure that the load-progress-bar.js and progress-bar.html are in the same directory.
- Make NGSD screens are loaded in before progress bar.
